package com.capgemini.airlinereservationsystemcollections.exception;

public class AirLineReservationSystemException extends RuntimeException{

}
