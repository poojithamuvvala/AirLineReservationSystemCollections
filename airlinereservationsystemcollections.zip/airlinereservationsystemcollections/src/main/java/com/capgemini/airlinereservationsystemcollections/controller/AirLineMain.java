package com.capgemini.airlinereservationsystemcollections.controller;

public class AirLineMain {

}
