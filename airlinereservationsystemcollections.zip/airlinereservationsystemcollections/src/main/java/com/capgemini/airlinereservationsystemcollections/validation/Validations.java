package com.capgemini.airlinereservationsystemcollections.validation;

public class Validations {

}
