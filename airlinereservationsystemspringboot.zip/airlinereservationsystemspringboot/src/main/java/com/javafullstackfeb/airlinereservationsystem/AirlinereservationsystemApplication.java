package com.javafullstackfeb.airlinereservationsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirlinereservationsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(AirlinereservationsystemApplication.class, args);
	}

}
