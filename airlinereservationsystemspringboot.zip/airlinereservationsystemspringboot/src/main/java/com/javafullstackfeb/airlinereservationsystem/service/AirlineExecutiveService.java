package com.javafullstackfeb.airlinereservationsystem.service;

import com.javafullstackfeb.airlinereservationsystem.beans.AirlineExecutiveBeans;

public interface AirlineExecutiveService {

	public AirlineExecutiveBeans viewFlightOccupancy(String flightNumber);

}
